<?php

declare(strict_types=1);

namespace Doctrine\Migrations\Exception;

use Throwable;

interface MigrationException extends Throwable
{
}
