<?php

namespace Doctrine\Bundle\DoctrineBundle\Repository;

/**
 * This interface signals that your repository should be loaded from the container.
 */
interface ServiceEntityRepositoryInterface
{
}
