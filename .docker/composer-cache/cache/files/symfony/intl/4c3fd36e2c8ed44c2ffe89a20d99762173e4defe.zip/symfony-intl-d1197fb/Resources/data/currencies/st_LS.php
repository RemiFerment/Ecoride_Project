<?php

return [
    'Names' => [
        'LSL' => [
            'M',
            'LSL',
        ],
    ],
];
