<?php

return [
    'Names' => [
        'TND' => [
            'DT',
            'dinar tunisien',
        ],
    ],
];
