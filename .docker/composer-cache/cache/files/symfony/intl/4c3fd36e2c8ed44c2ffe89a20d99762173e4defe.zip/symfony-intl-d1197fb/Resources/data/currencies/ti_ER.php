<?php

return [
    'Names' => [
        'ERN' => [
            'Nfk',
            'ኤርትራዊ ናቕፋ',
        ],
    ],
];
