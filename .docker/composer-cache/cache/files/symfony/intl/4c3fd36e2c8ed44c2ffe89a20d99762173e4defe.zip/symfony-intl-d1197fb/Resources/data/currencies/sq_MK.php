<?php

return [
    'Names' => [
        'MKD' => [
            'den',
            'Denari maqedonas',
        ],
    ],
];
