import { mergeConfig } from 'vitest/config';
import configShared from '../../../vitest.config.browser.mjs';

export default mergeConfig(configShared, {});
